The programs works fine as I have ran it several times and tested it as best I can. I have yet to find a major issue with the code, however I do not know of any instructions on getting rid of the pre-made students in the program in the registry.java file. If I was supposed to get rid of the pre-made students then sorry but I did change the code so that they would be added into their TreeMaps. While using the scheduler program there are times that it becomes slow but it does perform what it should. 

Note** there is an extra program called schedulerException which is my custom made exception for scheduler so if this file is not with it, scheduler will not work.

